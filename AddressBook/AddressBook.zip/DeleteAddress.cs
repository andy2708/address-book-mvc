﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AddressBook
{
    internal class DeleteAddress
    {
        internal void DeleteEntryFromAddressBook(int uniqueId)
        {
            //Read the xml file
            XmlRead read = new XmlRead();
            AddressInfo addressInfo = read.ReadXML();
            //Find the desired address
            AddressInfo.Address address = addressInfo.address.Where(x => x.uniqueId == uniqueId).First();
            //remove it from the list
            addressInfo.address.Remove(address);
            //Write the xml back
            XmlWrite write = new XmlWrite();
            write.WriteXML(addressInfo);
        }
        internal void DeleteEntryFromAddressBook(AddressInfo.Address address)
        {
            DeleteEntryFromAddressBook(address.uniqueId);
        }

    }
}
