﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AddressBook
{
    internal class EditAddress
    {
      
        internal void EditEntryInAddressBook(AddressInfo.Address newAddress)
        {
            XmlRead read = new XmlRead();
            AddressInfo addressInfo = read.ReadXML();
            //Select the old address and store that value so we can remove it later on.
            AddressInfo.Address originalAddress = addressInfo.address.Where(x => x.uniqueId == newAddress.uniqueId).First();
            //Add the new updated address to the list
            addressInfo.address.Add(newAddress);
            //Remove the old Address from list
            addressInfo.address.Remove(originalAddress);
            //Write back to the file
            XmlWrite write = new XmlWrite();
            write.WriteXML(addressInfo);
        }
        
    }
}
