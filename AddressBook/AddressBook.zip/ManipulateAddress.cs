﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AddressBook
{
    internal class ManipulateAddress
    {
        internal List<AddressInfo.Address> OrderAddressByFirstName()
        {
            XmlRead read = new XmlRead();
            AddressInfo addressInfo = read.ReadXML();
            return addressInfo.address.OrderBy(x => x.firstName).ToList();
        }
        internal List<AddressInfo.Address> OrderAddressDescendingByFirstName()
        {
            XmlRead read = new XmlRead();
            AddressInfo addressInfo = read.ReadXML();
            return addressInfo.address.OrderByDescending(x => x.firstName).ToList();
        }
        internal List<AddressInfo.Address> OrderAddressByLastName()
        {
            XmlRead read = new XmlRead();
            AddressInfo addressInfo = read.ReadXML();
            return addressInfo.address.OrderBy(x => x.lastName).ToList();
        }
        internal List<AddressInfo.Address> OrderAddressDescendingByLastName()
        {
            XmlRead read = new XmlRead();
            AddressInfo addressInfo = read.ReadXML();
            return addressInfo.address.OrderByDescending(x => x.lastName).ToList();
        }
        
    }
}
